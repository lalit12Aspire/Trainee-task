import { Component } from '@angular/core';
import { HomeComponent } from "../home/home.component";

@Component({
    selector: 'app-flight',
    standalone: true,
    templateUrl: './flight.component.html',
    styleUrl: './flight.component.css',
    imports: [HomeComponent]
})
export class FlightComponent {

}
