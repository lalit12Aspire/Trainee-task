import { Component } from '@angular/core';
import { HomeComponent } from "../home/home.component";
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
    selector: 'app-hotel',
    standalone: true,
    templateUrl: './hotel.component.html',
    styleUrl: './hotel.component.css',
    imports: [RouterOutlet, RouterLink, HomeComponent]
})
export class HotelComponent {

}
