import { Component } from '@angular/core';
import { HomeComponent } from "../home/home.component";

@Component({
    selector: 'app-bus',
    standalone: true,
    templateUrl: './bus.component.html',
    styleUrl: './bus.component.css',
    imports: [HomeComponent]
})
export class BusComponent {

}
