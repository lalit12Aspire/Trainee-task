import { Routes } from '@angular/router';
import { SubmitComponent } from './submit/submit.component';

export const routes: Routes = [
    {path:"app-submit", component:SubmitComponent}
];
